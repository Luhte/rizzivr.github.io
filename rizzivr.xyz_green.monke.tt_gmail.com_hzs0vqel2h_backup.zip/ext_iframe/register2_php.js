var com_adswizz_register_PROTOCOL_VERSION = '2.2.0';

if (typeof com_adswizz_synchro_listenerid === 'undefined') {
    var com_adswizz_synchro_listenerid = '62fa4f09dc98feee0d0f8d8b574bf09b';
}
else {
    com_adswizz_synchro_listenerid = '62fa4f09dc98feee0d0f8d8b574bf09b';
}

if (typeof com_adswizz_synchro_listnerid === 'undefined') {
    var com_adswizz_synchro_listnerid = com_adswizz_synchro_listenerid; // backwards compatibility
}
else {
    com_adswizz_synchro_listnerid = com_adswizz_synchro_listenerid; // backwards compatibility
}
var aw_0_req_gdpr = false;
var us_privacy = '';